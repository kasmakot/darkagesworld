<?

class RegisterController extends ActionController
{
    public function init()
    {
    }

    public function IndexAction()
    {
        print 'register-index';
    }

}
